#ifndef OPERAÇÕES_H
#define OPERAÇÕES_H

void negative(int lin, int col, int cor, int mat[1000][1000]);
void vert_invert(int lin, int col, int cor, int mat[1000][1000]);
void hor_invert(int lin, int col, int cor, int mat[1000][1000]);
void rot_right(int lin, int col, int cor, int mat[1000][1000]);
void dark_edg(int lin, int col, int cor, int esc, int mat[1000][1000]);
void rot_left(int lin, int col, int cor, int mat[1000][1000]);

#endif /* OPERAÇÕES_H */