#include <iostream>
#include <fstream>
#include <stdlib.h>

using namespace std;

int i, j, count = 0;
    
void negative(int lin, int col, int cor, int mat[1000][1000]){
    int *v;
    cout << endl;
    ofstream myfile1;
    myfile1.open ("negative.pgm");
    if (myfile1.is_open()){
        myfile1 << "P2" << endl;
        myfile1 << col << " " << lin << endl;
        myfile1 << cor << endl;
        v = (int *) malloc(sizeof(int) * (col*lin));
        for(i = 0; i < lin; i++){                           //leitura da imagem (vetor v recebe todos pixels)
            for(j = 0; j < col; j++){
                *v = mat[i][j];
                v = v + 1;
            }
        }    
        v = v - (lin*col);                                  //volta o vetor v para a primeira posição
        for(i = 0; i < lin; i++){
            for(j = 0; j < col; j++){
                *v = cor - *v;                              //formula para negativar
                myfile1 << *v << " ";
                v = v + 1;
            }
            myfile1 << endl;
        }
    }
    myfile1.close();
    cout << "Imagem gerada!" << endl;
    cout << endl;    
}

void vert_invert(int lin, int col, int cor, int mat[1000][1000]){
    int *v, *vert;
    cout << endl;
    ofstream myfile2;
    myfile2.open ("vert_invert.pgm");
    if (myfile2.is_open()){
        myfile2 << "P2" << endl;
        myfile2 << col << " " << lin << endl;
        myfile2 << cor << endl;
        v = (int *) malloc(sizeof(int) * (lin*col));
        vert = (int *) malloc(sizeof(int) * (lin*col));
        for(i = 0; i < lin; i++){                                    //leitura da imagem (vetor v recebe todos pixels)
            for(j = 0; j < col; j++){
                *v = mat[i][j];
                v = v + 1;
            }
        }
        v = v - col;                                                 //começa na primeira posicao da ultima linha
        for(count = 0; count < lin; count++){
            for(i = 0; i < col; i++){
                *vert = *v;
                v = v + 1;                                           //até chegar na ultima posicao da linha
                vert = vert + 1;
            }
            v = v - (col*2);                                         //v volta para o começo da proxima ultima linha
        }
        vert = vert - (lin*col);                                     //vert volta pra primeira posição
        for(i = 0; i < lin; i++){
            for(j=0;j<col;j++){
                myfile2 << *vert << " ";                             //escrever o resultado da matriz invertida
                vert = vert + 1;

            }
            myfile2 << endl;
        }
    }
    myfile2.close();
    cout << "Imagem gerada!" << endl;
    cout << endl;    
}

void hor_invert(int lin, int col, int cor, int mat[1000][1000]){
    int *v, *hor;
    cout << endl;
    ofstream myfile3;
    myfile3.open ("hor_invert.pgm");
    if (myfile3.is_open()){
        myfile3 << "P2" << endl;
        myfile3 << col << " " << lin << endl;
        myfile3 << cor << endl;
        v = (int *) malloc(sizeof(int)*(lin*col));
        hor = (int *) malloc(sizeof(int)*(lin*col));
        for(i = 0; i < lin; i++){                          //leitura da imagem (vetor v recebe todos pixels)
            for(j = 0; j < col; j++){
                *v = mat[i][j];
                v = v + 1;
            }
        }
        v = v - ((lin-1)*col) - 1;                         //volta para o fim da primeira linha (pixel)
        for(count = 0; count < lin; count++){
            for(i = 0; i < col; i++){
                *hor = *v;
                v = v - 1;                                 //até voltar pra primeira posicao da linha
                hor = hor + 1;
            }
            v = v + (col*2);                               //v vai para o final da proxima linha
        }
        hor = hor - (lin*col);                             //hor volta pra primeira posição
        for(i = 0; i < lin; i++){
            for(j = 0; j < col; j++){
                myfile3 << *hor << " ";                    //escrever o resultado da matriz invertida
                hor = hor+1;
            }
            myfile3 << endl;
        }
    }
    myfile3.close();
    cout << "Imagem gerada!" << endl;
    cout << endl;
}

void rot_right(int lin, int col, int cor, int mat[1000][1000]){
    int *v, *gir_d; 
    int count2;
    cout << endl;
    ofstream myfile4;
    myfile4.open ("rot_right.pgm");
    if (myfile4.is_open()){
        myfile4 << "P2" << endl;
        myfile4 << lin << " " << col << endl;
        myfile4 << cor << endl;
        v = (int *) malloc(sizeof (int)*(lin * col));
        gir_d = (int *) malloc(sizeof (int)*(lin * col));

        for (i = 0; i < lin; i++){                                  //leitura da imagem (vetor v recebe todos pixels)
            for(j = 0; j < col; j++){
                *v = mat[i][j];
                v = v + 1;
            }
        }
        v = v - col;                                                //volta para o inicio da ultima linha (vetor está no seu final e volta col posições)
        for (count2 = 0; count2 < col; count2++){                   //percorre as colunas da esquerda pra direita
            for (count = 0; count < lin; count++){                  //vai subindo as linhas da imagem e guardando em g (na sequencia do vetor resposta)
                if (count > 0)                                      //na primeira execução ja está na posição correta
                    v = v - col;                                    //sobe a linha após a primeira execuçãp

                *gir_d = *v;
                gir_d = gir_d + 1;                                  //vetor gir_d vai na sequencia
            }
            v = v + ((lin-1) * col) + 1;                            //após subir até a primeira linha, a posição em desce até a posição inicial
        }                                                           // de execução, e então acrescenta-se +1 para ir à direita e fazer o mesmo procedimento com a segunda coluna

        gir_d = gir_d - (lin*col);                                  //volta ao inicio de gir_d
        for (i = 0; i < col; i++){                                  //troquei linha e coluna de lugar
            for (j = 0; j < lin; j++) {
                myfile4 << *gir_d << " ";                           //escreve o resultado da imagem girada
                gir_d = gir_d + 1;
            }
            myfile4 << endl;
        }
    }
    myfile4.close();
    cout << "Imagem gerada!" << endl;
    cout << endl;    
}

void dark_edg(int lin, int col, int cor, int esc, int mat[1000][1000]){
    int pula = 1, max;
    int *v;                                                 //leitura da imagem (vetor v recebe todos pixels)
    cout << endl;
    ofstream myfile5;
    myfile5.open ("dark_edg.pgm");
    if (myfile5.is_open()){
        myfile5 << "P2" << endl;
        myfile5 << col << " " << lin << endl;
        myfile5 << cor << endl; 
        v = (int *) malloc(sizeof(int) * (lin*col));        //alocando memoria para o vetor
        v = &mat[0][0];
        for (i = 0; i < lin; i++){
            for(j = 0; j < col; j++){                       //atribuindo os pixels ao vetor
                *v = mat[i][j];
                v = v + 1;
            }
        }
        v = &mat[0][0];                                     //voltando v à sua primeira posição
        i = 0;
        max = (2 * (lin/10) + 2 * (col/10));                //escurece 20% da imagem (bordas de tamanho 10%)
        while(esc > 0 && i < max){                          //escurece > 0  e i(voltas escurecendo) < max(20% do perímetro)
            if (i > 0){    
                v = v + col;                                // desce uma posição quando não é a primeira borda
                *v = *v - esc;                              //atribui escurecimento ao primeiro elemento da sub-borda
            }
            for(count = 0; count < lin - pula; count++){    //escurece descendo a imagem
                v = v + col;
                *v = *v - esc;
            }
            i++;                                            //conta 1 pedaço de borda concluído
            for(count = 0; count < col - pula; count++){    //escure seguindo à direita
                v = v + 1;
                *v = *v - esc;
            }
            i++;
            for(count = 0; count < lin - pula; count++){    //escurece subindo a borda
                v = v - col;
                *v = *v - esc;
            }
            i++;
            for(count = 1; count < col - pula; count++){     //escurece seguindo à esquerda, voltando a posição inicial
                                                             //count = 1 para parar na segunda posição da borda e não entrar em loop infinito
                v = v - 1;
                *v = *v - esc;
            }
            i++;
            esc = esc - 2;                                   //variavel escurecer diminui para ser menor nas bordas mais centrais
            pula = pula + 2;                                 //elimina a borda externa e vai para a próxima
        }
        v = &mat[0][0];
        for (i = 0; i < lin; i++){
            for (j = 0; j < col; j++){
                myfile5 << *v << " ";                        //escreve a imagem escurecida
                v = v + 1;
            }
            myfile5 << endl;
        }       
    }
    myfile5.close();
    cout << "Imagem gerada!" << endl;
    cout << endl;
}
void rot_left(int lin, int col, int cor, int mat[1000][1000]){
    int *v, *gir_e; 
    int count2;
    cout << endl;
    ofstream myfile6;
    myfile6.open ("rot_left.pgm");
    if (myfile6.is_open()){
        myfile6 << "P2" << endl;
        myfile6 << lin << " " << col << endl;
        myfile6 << cor << endl;
        v = (int *) malloc(sizeof (int)*(lin * col));
        gir_e = (int *) malloc(sizeof (int)*(lin * col));

        for (i = 0; i < lin; i++){                                  //leitura da imagem (vetor v recebe todos pixels)
            for(j = 0; j < col; j++){
                *v = mat[i][j];
                v = v + 1;
            }
        }
        v = v - ((lin - 1) *col) -1;                                //volta para o inicio da ultima linha (vetor está no seu final e volta col posições)
        for (count2 = 0; count2 < col; count2++){                   //percorre as colunas da esquerda pra direita
            for (count = 0; count < lin; count++){                  //vai subindo as linhas da imagem e guardando em g (na sequencia do vetor resposta)
                if (count > 0)                                      //na primeira execução ja está na posição correta
                    v = v + col;                                    //sobe a linha após a primeira execuçãp
                *gir_e = *v;
                gir_e = gir_e + 1;                                  //vetor gir_e vai na sequencia
            }
            v = v - ((lin-1) * col) - 1;                            //após subir até a primeira linha, a posição em desce até a posição inicial
        }                                                           // de execução, e então acrescenta-se +1 para ir à direita e fazer o mesmo procedimento com a segunda coluna

        gir_e = gir_e - (lin*col);                                  //svolta ao inicio de gir_e
        for (i = 0; i < col; i++){                                  //troquei linha e coluna de lugar
            for (j = 0; j < lin; j++) {
                myfile6 << *gir_e << " ";                           //escreve o resultado da imagem girada
                gir_e = gir_e + 1;
            }
            myfile6 << endl;
        }
    }
    myfile6.close();
    cout << "Imagem gerada!" << endl;
    cout << endl;    
}