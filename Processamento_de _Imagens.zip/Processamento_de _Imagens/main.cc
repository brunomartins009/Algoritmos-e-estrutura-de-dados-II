/*---------------------------------------------------------------
 ∗ UNIFAL − Universidade Federal de Alfenas.
 ∗ BACHARELADO EM CIENCIA DA COMPUTACAO.
 ∗ Trabalho   : Processamento de Imagens com Ponteiros
 ∗ Disciplina : Aeds II
 ∗ Professor  : Paulo Alexandre Bressan
 ∗ Alunos     : Bruno Martins Cordeiro;  Matrícula: 2020.1.08.006
 ∗              Luis Gustavo Silva Piza; Matrícula: 2020.1.08.021
 ∗ Data       : 21/12/2021
 ∗------------------------------------------------------------*/
#include <iostream>
#include <fstream>
#include "opera.h"

using namespace std;

char op;
string tip;
int cod, lin, col, cor, esc;
int mat[1000][1000];

int main() {
    cout << "+-----------------------------+" << endl;
    cout << "|    Operações com imagens    |" << endl;
    cout << "| 1: Imagem negativa          |" << endl; 
    cout << "| 2: Inversão vertical        |" << endl;
    cout << "| 3: Inversão Horizontal      |" << endl;
    cout << "| 4: Rotação a direita        |" << endl;
    cout << "| 5: Escurecimento das bordas |" << endl;
    cout << "| 6: Rotação a esquerda       |" << endl;
    cout << "| 0: Encerrar                 |" << endl;
    cout << "+-----------------------------+" << endl;    
    scanf("%d", &cod);
    while(cod < 0 || cod > 6){
        cout << "Código não identificado! Insira novamente: " << endl;
        scanf("%d", &cod);
    }
    while(cod != 0){
        if (cod == 1) {
            ifstream myfile1("stanford.pgm");
            if (myfile1.is_open()) {
                while (!myfile1.eof()) {
                    myfile1 >> tip; //resgistra o tipo de arquivo
                    myfile1 >> col; //registra o numero de colunas
                    myfile1 >> lin; //registra o numero de linhas
                    myfile1 >> cor; //registra o max de cor da imagem
                    for (int i = 0; i < lin; i++) {
                        for (int j = 0; j < col; j++) {
                            myfile1 >> mat[i][j]; //registra a imagem em uma matriz que será usada nas operação
                        }
                        cout << endl;
                    }
                    cout << endl;
                }
                myfile1.close();
            }
            cout << "+--------------------+" << endl;
            cout << "|  Negativar imagem  |" << endl;
            cout << "+--------------------+" << endl;
            cout << "Gerando imagem..." << endl;
            negative(lin, col, cor, mat);
        }
        else if(cod == 2) {
            ifstream myfile1("stanford.pgm");
            if (myfile1.is_open()) {
                while (!myfile1.eof()) {
                    myfile1 >> tip; //resgistra o tipo de arquivo
                    myfile1 >> col; //registra o numero de colunas
                    myfile1 >> lin; //registra o numero de linhas
                    myfile1 >> cor; //registra o max de cor da imagem
                    for (int i = 0; i < lin; i++) {
                        for (int j = 0; j < col; j++) {
                            myfile1 >> mat[i][j]; //registra a imagem em uma matriz que será usada nas operação
                        }
                        cout << endl;
                    }
                    cout << endl;
                }
                myfile1.close();
            }
            cout << "+---------------------+" << endl;
            cout << "|  Inversão vertical  |" << endl;
            cout << "+---------------------+" << endl;
            cout << "Gerando imagem..." << endl;            
            vert_invert(lin, col, cor, mat);
        }
        else if(cod == 3) {
            ifstream myfile1("stanford.pgm");
            if (myfile1.is_open()) {
                while (!myfile1.eof()) {
                    myfile1 >> tip; //resgistra o tipo de arquivo
                    myfile1 >> col; //registra o numero de colunas
                    myfile1 >> lin; //registra o numero de linhas
                    myfile1 >> cor; //registra o max de cor da imagem
                    for (int i = 0; i < lin; i++) {
                        for (int j = 0; j < col; j++) {
                            myfile1 >> mat[i][j]; //registra a imagem em uma matriz que será usada nas operação
                        }
                        cout << endl;
                    }
                    cout << endl;
                }
                myfile1.close();
            }
            cout << "+-----------------------+" << endl;
            cout << "|  Inversão horizontal  |" << endl;
            cout << "+-----------------------+" << endl;
            cout << "Gerando imagem..." << endl;            
            hor_invert(lin, col, cor, mat);
        }
        else if(cod == 4) {
            ifstream myfile1("stanford.pgm");
            if (myfile1.is_open()) {
                while (!myfile1.eof()) {
                    myfile1 >> tip; //resgistra o tipo de arquivo
                    myfile1 >> col; //registra o numero de colunas
                    myfile1 >> lin; //registra o numero de linhas
                    myfile1 >> cor; //registra o max de cor da imagem
                    for (int i = 0; i < lin; i++) {
                        for (int j = 0; j < col; j++) {
                            myfile1 >> mat[i][j]; //registra a imagem em uma matriz que será usada nas operação
                        }
                        cout << endl;
                    }
                    cout << endl;
                }
                myfile1.close();
            }
            cout << "+---------------------+" << endl;
            cout << "|  Rotação a direita  |" << endl;
            cout << "+---------------------+" << endl;
            cout << "Gerando imagem..." << endl;            
            rot_right(lin, col, cor, mat);
        }
        else if(cod == 5) {
            ifstream myfile1("stanford.pgm");
            if (myfile1.is_open()) {
                while (!myfile1.eof()) {
                    myfile1 >> tip; //resgistra o tipo de arquivo
                    myfile1 >> col; //registra o numero de colunas
                    myfile1 >> lin; //registra o numero de linhas
                    myfile1 >> cor; //registra o max de cor da imagem
                    for (int i = 0; i < lin; i++) {
                        for (int j = 0; j < col; j++) {
                            myfile1 >> mat[i][j]; //registra a imagem em uma matriz que será usada nas operação
                        }
                        cout << endl;
                    }
                    cout << endl;
                }
                myfile1.close();
            }
            cout << "+----------------------------+" << endl;
            cout << "|  Escurecimanto das bordas  |" << endl;
            cout << "+----------------------------+" << endl;
            cout << "Digite o valor do escurecimento: " << endl;
            scanf("%d", &esc);            
            cout << "Gerando imagem..." << endl;            
            dark_edg(lin, col, cor, esc, mat);
        }
        else if(cod == 6){
            ifstream myfile1("stanford.pgm");
            if (myfile1.is_open()) {
                while (!myfile1.eof()) {
                    myfile1 >> tip; //resgistra o tipo de arquivo
                    myfile1 >> col; //registra o numero de colunas
                    myfile1 >> lin; //registra o numero de linhas
                    myfile1 >> cor; //registra o max de cor da imagem
                    for (int i = 0; i < lin; i++) {
                        for (int j = 0; j < col; j++) {
                            myfile1 >> mat[i][j]; //registra a imagem em uma matriz que será usada nas operação
                        }
                        cout << endl;
                    }
                    cout << endl;
                }
                myfile1.close();
            }
            cout << "+----------------------+" << endl;
            cout << "|  Rotação a esquerda  |" << endl;
            cout << "+----------------------+" << endl;       
            cout << "Gerando imagem..." << endl;            
            rot_left(lin, col, cor, mat);            
        }
        cout << "Realizar outra operação? S ou N" << endl;
        scanf("%s", &op);
        if(op == 'S' || op == 's') {
            cout << "+-----------------------------+" << endl;
            cout << "|    Operações com imagens    |" << endl;
            cout << "| 1: Imagem negativa          |" << endl;
            cout << "| 2: Inversão vertical        |" << endl;
            cout << "| 3: Inversão Horizontal      |" << endl;
            cout << "| 4: Rotação a direita        |" << endl;
            cout << "| 5: Escurecimento das bordas |" << endl;
            cout << "| 6: Rotação a esquerda      |" << endl;
            cout << "| 0: Encerrar                 |" << endl;
            cout << "+-----------------------------+" << endl;
            scanf("%d", &cod);
            while (cod < 0 || cod > 6) {
                cout << "Código não identificado! Insira novamente: " << endl;
                scanf("%d", &cod);
            }
        }
        else{
            cod = 0;
        }
    }
    return 0;
}
